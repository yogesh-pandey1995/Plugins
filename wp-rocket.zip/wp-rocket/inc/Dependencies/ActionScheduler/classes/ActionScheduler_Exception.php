<?php

/**
 * ActionScheduler Exception Interface.
 *
 * Facilitates catching Exceptions unique to Action Scheduler.
 *
 * @package ActionScheduler
 * @since %VERSION%
 */
interface ActionScheduler_Exception {}
